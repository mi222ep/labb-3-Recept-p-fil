3.1 Recept på fil
=================
[3-1-recept-pa-fil.pdf](https://github.com/1dv402/kursmaterial/raw/master/Laborationsuppgifter/3-1-recept-pa-fil.pdf)

![ScreenShot](README.png)

"Du ska komplettera en något större applikation för hantering av recept. Applikationen är i stort färdig men behöver kompletteras med fyra metoder för att det ska gå att visa recept, hämta recept från och skriva recept till en textfil...."

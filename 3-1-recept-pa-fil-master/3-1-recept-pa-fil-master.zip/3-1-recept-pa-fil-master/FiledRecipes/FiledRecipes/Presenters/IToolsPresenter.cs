﻿using FiledRecipes.App;
using System;

namespace FiledRecipes.Presenters
{
    /// <summary>
    /// 
    /// </summary>
    public interface IToolsPresenter : ILanguageChanged
    {
    }
}

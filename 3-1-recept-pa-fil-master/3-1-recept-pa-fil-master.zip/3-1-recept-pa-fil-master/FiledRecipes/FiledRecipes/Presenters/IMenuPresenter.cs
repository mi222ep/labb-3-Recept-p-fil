﻿using FiledRecipes.App.Input;

namespace FiledRecipes.Presenters
{
    /// <summary>
    /// 
    /// </summary>
    public interface IMenuPresenter
    {
        ICommand GetCommand();
    }
}

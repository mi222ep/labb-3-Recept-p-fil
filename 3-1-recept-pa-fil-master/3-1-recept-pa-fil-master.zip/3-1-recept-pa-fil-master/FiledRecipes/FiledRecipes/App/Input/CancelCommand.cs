﻿namespace FiledRecipes.App.Input
{
    public class CancelCommand : CommandBase
    {
        public override void Execute()
        {
        }
    }
}

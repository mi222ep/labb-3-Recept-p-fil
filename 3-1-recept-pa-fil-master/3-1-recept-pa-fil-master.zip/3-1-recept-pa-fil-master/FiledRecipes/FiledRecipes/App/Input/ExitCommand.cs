﻿
namespace FiledRecipes.App.Input
{
    public class ExitCommand : CommandBase
    {
        public override void Execute()
        {
        }
    }
}
